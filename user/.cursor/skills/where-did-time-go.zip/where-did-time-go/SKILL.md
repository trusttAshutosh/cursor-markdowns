---
name: where-did-time-go
description: >-
  Build a chronological daily workflog as a table (time, duration, work, ticket,
  chat) with total duration at the end. Use when the user asks where time went,
  daily workflow, workflog, timeline of today's chats,
  /where-did-time-go, or standup that must include investigation with no ticket.
disable-model-invocation: true
---

# Where did time go

Produce one **unified daily timeline** across **all** Cursor chats that day:
blocks from every session merged into a single list, sorted **start → end** by
time — including investigation that never became a commit or Jira ticket.

Never group the final output by chat/project. Chats are only the source; the
deliverable is one chronological **table** plus a **total duration** footer.

## Trigger

Default window: **today** (local timezone). Also: yesterday, last N days, a date.

## Workflow

```
- [ ] 1. Resolve day + person
- [ ] 2. Collect sessions for that day
- [ ] 3. Build time blocks (start → end → topic)
- [ ] 4. Sort chronologically; merge overlaps
- [ ] 5. Optionally attach commits to blocks
- [ ] 6. Emit workflog (table + total duration footer)
```

### 1. Resolve day + person

- Day from user request or `date +%Y-%m-%d`.
- Person = current user (`git config user.name` / email local-part). One person
  per run unless the user names someone else (still only their local transcripts).

### 2. Collect sessions

Scan: `~/.cursor/projects/*/agent-transcripts/**/*.jsonl`

Fast filter (mtime that day):

```bash
find "$HOME/.cursor/projects" -path "*/agent-transcripts/*/*.jsonl" -newermt "YYYY-MM-DD" ! -newermt "YYYY-MM-DD +1 day" 2>/dev/null
```

Optional helper (if Python responds quickly):

```bash
/c/Python314/python ~/.cursor/skills/where-did-time-go/scripts/list_sessions.py --since YYYY-MM-DD
```

If the helper hangs, use `find` + read files yourself.

Also include a file if any embedded `<timestamp>...` falls on that day even when
mtime is later.

### 3. Build time blocks from each session

For each matching `.jsonl`:

1. Pull every `<timestamp>...` and every `<user_query>...`.
2. **Session start** = earliest timestamp that day (else first user turn that day).
3. **Session end** = latest timestamp that day (else file mtime if same day).
4. **Duration** = end − start (label `~`). If only one stamp → `duration unknown`.
5. **Topic** = short outcome from user queries + final assistant conclusion
   (what was worked on — not tool spam). Prefer functional wording.
6. Note Jira keys if present (`PROJ-123` pattern only); leave **Ticket** blank when none.
7. Cite `[title](uuid)` with transcript uuid (folder/stem).

Split one long chat into multiple blocks **only** when the topic clearly changes
(new problem / new ticket) with timestamps far apart; otherwise one block per session.

### 4. One timeline across all chats

1. Collect blocks from **every** matching session (all projects).
2. Sort by **start time ascending** (then end time) into **one** list.
3. Do **not** nest under chat names or project folders in the final output.
4. Same topic continuing in a later message of the same chat → keep/extend one block.
5. Different chats interleaved in time → interleave their blocks in clock order
   (Chat A 9:00, Chat B 9:20, Chat A 10:00 → that order).
6. Heavy overlap on the same topic → merge; different topics overlapping → list
   both and mark `(overlap)`.
7. Drop pure meta (plugin how-to) unless user asked for the full day.

### 5. Commits (optional enrichment)

Same rules as `what-did-i-get-done` for that day. Attach a commit under the
block it belongs to when obvious; do not invent a separate timeline from commits
alone if chats already cover the work.

### 6. Output format (required)

**Single day timeline** — one **table**, rows in clock order, all chats mixed.
Always end with a **total duration** line.

```markdown
## Workflog — YYYY-MM-DD
**Person:** <name>

| # | Time | Duration | Work | Ticket | Chat |
|---|------|----------|------|--------|------|
| 1 | 08:10–08:55 | ~45m | OTP RCA | | [OTP RCA](uuid) |
| 2 | 09:05–09:25 | ~20m | DSA report DAO fix | PROJ-123 | [DSA report fix](uuid) |
| 3 | 14:05–14:45 | ~40m | Atlassian capture design | | [Work capture design](uuid) |

**Total duration:** ~1h 45m *(estimates from chat timestamps)*

**Wall clock:** 08:10–14:45 (~6h 35m span) — optional; include when gaps between blocks are large.
```

#### Table columns

| Column | Content |
|--------|---------|
| **#** | Row number, sort key = start time |
| **Time** | `HH:MM–HH:MM` block start–end |
| **Duration** | `~Xm` or `~Xh Ym`; use `unknown` if only one stamp |
| **Work** | One short phrase — what was done (outcome, not tool spam) |
| **Ticket** | Jira ID(s) only (e.g. `PROJ-123`, `AAN-601`); **leave blank** when none — never `no ticket`, prose, or repo names |
| **Chat** | `[title](uuid)` transcript cite |

Mark overlapping different-topic blocks with `(overlap)` in the **Work** cell.

#### Total duration (required footer)

1. Parse each row's **Duration** to minutes (`~1h 45m` → 105).
2. **Sum all rows** for the total.
3. Rows marked `(overlap)` that share the same clock window — count each row's
   duration once (do not double-count the same minutes twice). When unsure,
   sum naively and add: *(may double-count N min of overlap)*.
4. Format total as `~Xh Ym` (or `~Xm` if under 1h).
5. Always note estimates when timestamps are sparse: *(estimates from chat timestamps)*.

Example footer:

```markdown
**Total duration:** ~7h 20m *(estimates from chat timestamps; 31m overlap not double-counted)*
```

#### Spoken shape (optional, after the table)

> Ashutosh — 2026-07-31 — **~1h 45m total**  
> 08:10–08:55 OTP RCA · 09:05–09:25 DSA report DAO fix · 14:05–14:45 Atlassian capture design

Wrong: sections per chat (“Chat 1… Chat 2…”).  
Wrong: numbered list instead of table.  
Right: one table from earliest start to latest end, total at the bottom.

Rules:

- Sort key = block start time only (cross-chat).
- One row per block; keep **Work** to one line.
- **Ticket** column: Jira IDs only; blank cell if no linked ticket.
- Always state the date and **Total duration** footer.
- Durations are estimates from chat timestamps — say so if sparse.
- Do not create Jira unless explicitly asked this turn.
- No secrets, full logs, or stack traces.

## Guardrails

- Describe work performed, not unverified RCA as fact.
- Only local transcripts under `~/.cursor/projects`.
- If no chats and no commits that day: say so in one line.
